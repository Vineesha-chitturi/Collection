public class Program4 {
	public static void main(String[] args) {
		ContactList contactsList = new ContactList();
		
		contactsList.addContact("vin", 84393218);
		contactsList.addContact("parth", 98975595);
		
				
		System.out.println("vin: " + contactsList.doesContactNameExist("vin"));
		System.out.println("989754495: " + contactsList.doesContactNumberExist(989754495));
		
		System.out.println();
		contactsList.listAllContacts();
	}
}
